import os
import rdflib

from rdflib import plugin
from string import Template

class Sentics(object):

    def lookup(self, concept):
        print ('sdfsfdsdsfsdfhehheheehe')
        self.dirname = os.getcwd()
        self.sentic_local = os.path.join(self.dirname, "senticnet2.rdf.xml")
        print ('seht8b local: ', self.sentic_local)
        self.parsed_graph = rdflib.Graph().parse(self.sentic_local, format="xml")
        print('sffsfsfsfds')
        self.query_base = Template('PREFIX sentic: <http://sentic.net/api/> '\
                                   'SELECT ?pleasantness ?attention ?sensitivity ?aptitude '\
                                   'WHERE { '\
                                   '?concept sentic:text "$concept"; '\
                                   'sentic:pleasantness ?pleasantness; '\
                                   'sentic:attention ?attention; '\
                                   'sentic:sensitivity ?sensitivity; '\
                                   'sentic:aptitude ?aptitude. '\
                                   '}')
        print ('poarsed grasph: ' , self.parsed_graph)
        query_str = self.query_base.substitute(concept=concept)
        query = self.parsed_graph.query(str(query_str))
        if len(query) == 0: return None
        return dict((str(sentic), float(score)) for (sentic, score) in      query_get_bindings()[0].iteritems())

    